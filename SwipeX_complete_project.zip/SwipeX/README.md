# SwipeX — Swipe-Based Intelligent Job Discovery and Career Assistance Platform

This is a runnable educational MVP based on the uploaded SwipeX specification.

## Included
- React frontend
- FastAPI backend
- SQLite database for development
- JWT login/register
- Candidate resume upload
- PDF/DOCX/TXT parsing
- Skill extraction
- Transparent ATS baseline score
- TF-IDF + skill based resume/job matching
- Personalized recommendation endpoint
- Swipe left/right
- Application tracking
- Seed job dataset
- Docker support

## Project flow
Register/Login → Upload Resume → Resume Analysis → ATS Score → Job Recommendations → Swipe Jobs → Apply → Track Application

## Run backend on Windows
Open VS Code terminal at the SwipeX folder:

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
uvicorn backend.main:app --reload
```

Backend:
http://127.0.0.1:8000

Swagger API:
http://127.0.0.1:8000/docs

## Run frontend
Open a second terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## Docker
From the project root:

```powershell
docker compose up --build
```

The API will be available on port 8000.

## Important
The ML implementation is intentionally transparent and local for a beginner-friendly demo. It does not claim to reproduce a commercial ATS. The uploaded specification lists OpenAI, spaCy and sentence-transformers as possible technologies; those are not required to run this MVP.

## Dataset
`dataset/jobs.csv` is a small demo dataset. Replace it with a legally usable real job dataset for production.

## Database
SQLite file is created automatically as `backend/swipex.db` when the API starts. PostgreSQL can be introduced later for deployment.

## Security
The development JWT secret is in `backend/services/auth.py`. Change it and move it to an environment variable before deployment.

## API summary
- POST `/auth/register`
- POST `/auth/login`
- GET `/jobs`
- GET `/jobs/{job_id}`
- POST `/resumes/upload?user_id=...`
- GET `/resumes/latest?user_id=...`
- GET `/recommendations?user_id=...`
- POST `/swipes?user_id=...&job_id=...&action=right|left`
- GET `/swipes/applications?user_id=...`
