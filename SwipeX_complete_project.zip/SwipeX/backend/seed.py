import csv, json, os
from backend.database.db import SessionLocal
from backend.models.models import Job

def seed_jobs():
    db=SessionLocal()
    try:
        if db.query(Job).count()>0: return
        path=os.path.join(os.path.dirname(os.path.dirname(__file__)),"dataset","jobs.csv")
        with open(path,encoding="utf-8") as f:
            for row in csv.DictReader(f):
                db.add(Job(title=row["title"],company=row["company"],location=row["location"],
                    job_type=row["job_type"],category=row["category"],experience=row["experience"],
                    salary=row["salary"],skills=json.dumps([x.strip() for x in row["skills"].split("|")]),
                    description=row["description"],applicants=int(row["applicants"]),
                    posted_days_ago=int(row["posted_days_ago"])))
        db.commit()
    finally: db.close()
