from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.database.db import Base, engine, SessionLocal
from backend.models import models
from backend.routes import auth, jobs, resumes, recommendations, swipes
from backend.seed import seed_jobs

Base.metadata.create_all(bind=engine)
seed_jobs()

app=FastAPI(title="SwipeX API", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.include_router(auth.router)
app.include_router(jobs.router)
app.include_router(resumes.router)
app.include_router(recommendations.router)
app.include_router(swipes.router)

@app.get("/")
def root():
    return {"project":"SwipeX","status":"running","docs":"/docs"}
