from sqlalchemy import Column, Integer, String, Text, Float, ForeignKey, DateTime
from datetime import datetime
from backend.database.db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    email = Column(String(180), unique=True, index=True, nullable=False)
    phone = Column(String(30), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(30), default="candidate")

class Resume(Base):
    __tablename__ = "resumes"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    filename = Column(String(255))
    resume_text = Column(Text)
    ats_score = Column(Float, default=0)
    skills = Column(Text, default="[]")
    analysis = Column(Text, default="")

class Job(Base):
    __tablename__ = "jobs"
    id = Column(Integer, primary_key=True)
    title = Column(String(180), nullable=False)
    company = Column(String(180), nullable=False)
    location = Column(String(120))
    job_type = Column(String(50))
    category = Column(String(50))
    experience = Column(String(80))
    salary = Column(String(80))
    skills = Column(Text)
    description = Column(Text)
    applicants = Column(Integer, default=0)
    posted_days_ago = Column(Integer, default=1)

class Swipe(Base):
    __tablename__ = "swipes"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    job_id = Column(Integer, ForeignKey("jobs.id"))
    action = Column(String(20))
    created_at = Column(DateTime, default=datetime.utcnow)

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    job_id = Column(Integer, ForeignKey("jobs.id"))
    status = Column(String(30), default="Applied")
    created_at = Column(DateTime, default=datetime.utcnow)
