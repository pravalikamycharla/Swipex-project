from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.database.db import get_db
from backend.models.models import Swipe, Application, Job

router=APIRouter(prefix="/swipes",tags=["Swipes"])

@router.post("")
def swipe(user_id:int, job_id:int, action:str, db:Session=Depends(get_db)):
    s=Swipe(user_id=user_id,job_id=job_id,action=action)
    db.add(s)
    if action=="right":
        db.add(Application(user_id=user_id,job_id=job_id,status="Applied"))
        j=db.query(Job).filter(Job.id==job_id).first()
        if j: j.applicants += 1
    db.commit()
    return {"message": "Applied" if action=="right" else "Skipped"}

@router.get("/applications")
def applications(user_id:int,db:Session=Depends(get_db)):
    rows=db.query(Application,Job).join(Job,Application.job_id==Job.id).filter(Application.user_id==user_id).all()
    return [{"id":a.id,"status":a.status,"title":j.title,"company":j.company,"location":j.location} for a,j in rows]
