import json, os
from fastapi import APIRouter, Depends, File, UploadFile, Query, HTTPException
from sqlalchemy.orm import Session
from backend.database.db import get_db
from backend.models.models import Resume
from ml.resume_parser import extract_text
from ml.skill_extractor import extract_skills
from ml.ats_scorer import analyze

router = APIRouter(prefix="/resumes", tags=["Resume & ATS"])
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/upload")
async def upload_resume(user_id:int=Query(...), file:UploadFile=File(...), db:Session=Depends(get_db)):
    ext=os.path.splitext(file.filename)[1].lower()
    if ext not in [".pdf",".docx",".txt"]:
        raise HTTPException(400,"Upload PDF, DOCX or TXT only")
    path=os.path.join(UPLOAD_DIR, f"{user_id}_{file.filename}")
    with open(path,"wb") as f: f.write(await file.read())
    text=extract_text(path)
    skills=extract_skills(text)
    score,suggestions=analyze(skills,text)
    old=db.query(Resume).filter(Resume.user_id==user_id).first()
    if old:
        old.filename=file.filename; old.resume_text=text; old.skills=json.dumps(skills)
        old.ats_score=score; old.analysis=json.dumps(suggestions)
        r=old
    else:
        r=Resume(user_id=user_id,filename=file.filename,resume_text=text,
                 skills=json.dumps(skills),ats_score=score,analysis=json.dumps(suggestions))
        db.add(r)
    db.commit(); db.refresh(r)
    return {"id":r.id,"filename":r.filename,"ats_score":r.ats_score,
            "skills":skills,"analysis":suggestions}

@router.get("/latest")
def latest(user_id:int, db:Session=Depends(get_db)):
    r=db.query(Resume).filter(Resume.user_id==user_id).first()
    if not r: return {"message":"No resume uploaded"}
    return {"id":r.id,"filename":r.filename,"ats_score":r.ats_score,
            "skills":json.loads(r.skills or "[]"),"analysis":json.loads(r.analysis or "[]")}
