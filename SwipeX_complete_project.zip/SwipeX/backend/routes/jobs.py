import json
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.database.db import get_db
from backend.models.models import Job

router = APIRouter(prefix="/jobs", tags=["Jobs"])

def public_job(j):
    return {"id":j.id,"title":j.title,"company":j.company,"location":j.location,
            "job_type":j.job_type,"category":j.category,"experience":j.experience,
            "salary":j.salary,"skills":json.loads(j.skills or "[]"),
            "description":j.description,"applicants":j.applicants,
            "posted_days_ago":j.posted_days_ago}

@router.get("")
def list_jobs(category: str|None=None, location: str|None=None, db: Session=Depends(get_db)):
    q = db.query(Job)
    if category: q=q.filter(Job.category.ilike(f"%{category}%"))
    if location: q=q.filter(Job.location.ilike(f"%{location}%"))
    return [public_job(j) for j in q.all()]

@router.get("/{job_id}")
def get_job(job_id:int, db:Session=Depends(get_db)):
    return public_job(db.query(Job).filter(Job.id==job_id).first())
