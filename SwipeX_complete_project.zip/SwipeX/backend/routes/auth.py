from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from backend.database.db import get_db
from backend.models.models import User
from backend.services.auth import hash_password, verify_password, create_token

router = APIRouter(prefix="/auth", tags=["Authentication"])

class RegisterIn(BaseModel):
    name: str
    email: str
    phone: str | None = None
    password: str

class LoginIn(BaseModel):
    email: str
    password: str

@router.post("/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter((User.email == data.email) | (User.phone == data.phone)).first():
        raise HTTPException(400, "User already exists")
    user = User(name=data.name, email=data.email, phone=data.phone, password_hash=hash_password(data.password))
    db.add(user); db.commit(); db.refresh(user)
    return {"message":"Registration successful","user_id":user.id,"token":create_token(user.id)}

@router.post("/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"message":"Login successful","user_id":user.id,"token":create_token(user.id),"name":user.name}
