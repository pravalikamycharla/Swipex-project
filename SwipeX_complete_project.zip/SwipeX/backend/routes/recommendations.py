import json
from fastapi import APIRouter, Query, Depends
from sqlalchemy.orm import Session
from backend.database.db import get_db
from backend.models.models import Resume, Job, Swipe
from ml.recommender import recommend

router=APIRouter(prefix="/recommendations",tags=["Recommendations"])

@router.get("")
def recommendations(user_id:int=Query(...), db:Session=Depends(get_db)):
    r=db.query(Resume).filter(Resume.user_id==user_id).first()
    if not r: return []
    skills=json.loads(r.skills or "[]")
    swipes=db.query(Swipe).filter(Swipe.user_id==user_id).all()
    skipped={s.job_id for s in swipes}
    ranked=recommend(r.resume_text,skills,db.query(Job).all(),skipped)
    return [{"match_percentage":score,"job":{"id":j.id,"title":j.title,"company":j.company,
            "location":j.location,"job_type":j.job_type,"category":j.category,
            "experience":j.experience,"salary":j.salary,"skills":json.loads(j.skills or "[]"),
            "description":j.description,"applicants":j.applicants,"posted_days_ago":j.posted_days_ago}}
            for score,j in ranked[:10]]
