import jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta

SECRET = "swipex-development-secret-change-in-production"
ALGORITHM = "HS256"
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password): return pwd.hash(password)
def verify_password(password, hashed): return pwd.verify(password, hashed)
def create_token(user_id):
    return jwt.encode({"sub": str(user_id), "exp": datetime.utcnow()+timedelta(hours=24)}, SECRET, algorithm=ALGORITHM)
