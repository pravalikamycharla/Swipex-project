import re

SKILL_LIBRARY = [
    "python","java","c","c++","sql","javascript","react","html","css",
    "fastapi","django","flask","git","github","docker","aws","azure",
    "machine learning","deep learning","scikit-learn","pandas","numpy",
    "matplotlib","tensorflow","pytorch","nlp","spacy","sqlalchemy",
    "data analytics","data structures","algorithms","oops","rest api",
    "communication","excel","matlab","altium","vlsi","verilog","systemverilog",
    "linux","network security","ethical hacking"
]

def extract_skills(text: str):
    t = text.lower()
    found = []
    for skill in SKILL_LIBRARY:
        if re.search(r"(?<![a-z0-9])" + re.escape(skill.lower()) + r"(?![a-z0-9])", t):
            found.append(skill)
    return sorted(set(found))
