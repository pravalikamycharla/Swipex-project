def ats_score(skills, text):
    # Transparent baseline ATS score for the demo.
    if not text.strip():
        return 0.0
    coverage = min(len(skills) / 12.0, 1.0)
    length_bonus = min(len(text.split()) / 500.0, 1.0) * 0.15
    return round(min((coverage * 0.85 + length_bonus) * 100, 100), 1)

def analyze(skills, text):
    score = ats_score(skills, text)
    suggestions = []
    if score < 80:
        suggestions.append("Add more role-relevant technical keywords.")
    if len(text.split()) < 250:
        suggestions.append("Add concise project, internship and achievement details.")
    if "python" not in skills:
        suggestions.append("If applicable, include Python experience and projects.")
    if not suggestions:
        suggestions.append("Resume has good baseline ATS coverage; tailor keywords to each job.")
    return score, suggestions
