import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def match(resume_text, resume_skills, job):
    job_skills = json.loads(job.skills or "[]")
    skill_set = set(s.lower() for s in resume_skills)
    job_set = set(s.lower() for s in job_skills)
    skill_score = len(skill_set & job_set) / max(len(job_set), 1)

    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        mat = vectorizer.fit_transform([resume_text, job.description or ""])
        text_score = float(cosine_similarity(mat[0:1], mat[1:2])[0][0])
    except ValueError:
        text_score = 0.0

    return round((0.65 * skill_score + 0.35 * text_score) * 100, 1)
