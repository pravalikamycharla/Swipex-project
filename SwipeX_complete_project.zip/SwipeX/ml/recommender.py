from ml.job_matcher import match

def recommend(resume_text, skills, jobs, swiped_job_ids=None):
    swiped_job_ids = swiped_job_ids or set()
    results = []
    for job in jobs:
        if job.id in swiped_job_ids:
            continue
        score = match(resume_text, skills, job)
        results.append((score, job))
    return [x for x in sorted(results, key=lambda x: x[0], reverse=True)]
