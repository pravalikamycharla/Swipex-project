import React,{useEffect,useState} from "react";
import axios from "axios";
const API="http://127.0.0.1:8000";

export default function App(){
 const [page,setPage]=useState(localStorage.user_id?"dashboard":"login");
 const [user,setUser]=useState(localStorage.user_id||"");
 const [jobs,setJobs]=useState([]); const [recs,setRecs]=useState([]);
 const [apps,setApps]=useState([]); const [resume,setResume]=useState(null);
 const [form,setForm]=useState({name:"",email:"",phone:"",password:""});
 const [file,setFile]=useState(null); const [msg,setMsg]=useState("");

 const load=async()=>{
  if(!user)return;
  try{
   const [r1,r2,r3]=await Promise.all([
    axios.get(API+"/recommendations?user_id="+user),
    axios.get(API+"/jobs"),axios.get(API+"/swipes/applications?user_id="+user)
   ]);
   setRecs(r1.data);setJobs(r2.data);setApps(r3.data);
   const rr=await axios.get(API+"/resumes/latest?user_id="+user); if(rr.data.id)setResume(rr.data);
  }catch(e){setMsg(e.response?.data?.detail||"Backend connection error");}
 };
 useEffect(()=>{load()},[user]);

 const auth=async(type)=>{
  try{
   const url=type==="register"?"/auth/register":"/auth/login";
   const data=type==="register"?form:{email:form.email,password:form.password};
   const r=await axios.post(API+url,data); localStorage.user_id=r.data.user_id;
   setUser(r.data.user_id);setPage("dashboard");setMsg(r.data.message);
  }catch(e){setMsg(e.response?.data?.detail||"Error");}
 };
 const upload=async()=>{
  if(!file)return setMsg("Choose a resume first");
  const fd=new FormData();fd.append("file",file);
  try{const r=await axios.post(API+"/resumes/upload?user_id="+user,fd);
   setResume(r.data);setMsg("Resume analyzed successfully");load();
  }catch(e){setMsg(e.response?.data?.detail||"Upload failed")}
 };
 const swipe=async(id,action)=>{
  await axios.post(`${API}/swipes?user_id=${user}&job_id=${id}&action=${action}`);
  load();
 };
 const logout=()=>{localStorage.clear();setUser("");setPage("login")};

 if(page==="login"||page==="register") return <div className="auth"><div className="authbox">
  <h1>SwipeX</h1><p>AI-powered job discovery</p>
  {page==="register"&&<input placeholder="Name" onChange={e=>setForm({...form,name:e.target.value})}/>}
  <input placeholder="Email" onChange={e=>setForm({...form,email:e.target.value})}/>
  {page==="register"&&<input placeholder="Phone" onChange={e=>setForm({...form,phone:e.target.value})}/>}
  <input type="password" placeholder="Password" onChange={e=>setForm({...form,password:e.target.value})}/>
  <button onClick={()=>auth(page==="register"?"register":"login")}>{page==="register"?"Create account":"Login"}</button>
  <button className="link" onClick={()=>setPage(page==="register"?"login":"register")}>{page==="register"?"Already have an account? Login":"New user? Register"}</button>
  <p className="msg">{msg}</p>
 </div></div>;

 return <div><nav><b>SwipeX</b><span>AI Job Discovery</span><div><button onClick={()=>setPage("dashboard")}>Dashboard</button><button onClick={()=>setPage("resume")}>Resume</button><button onClick={()=>setPage("jobs")}>Jobs</button><button onClick={()=>setPage("applications")}>Applications</button><button onClick={logout}>Logout</button></div></nav>
 <main>
 {page==="dashboard"&&<><h2>Welcome to SwipeX 👋</h2><div className="stats"><div><b>{resume?.ats_score||0}%</b><small>ATS Score</small></div><div><b>{recs.length}</b><small>Recommendations</small></div><div><b>{apps.length}</b><small>Applications</small></div></div><h2>Top Recommended Jobs</h2><div className="grid">{recs.slice(0,4).map(x=><JobCard key={x.job.id} x={x} swipe={swipe}/>)}</div></>}
 {page==="resume"&&<section><h2>AI Resume Analyzer</h2><input type="file" accept=".pdf,.docx,.txt" onChange={e=>setFile(e.target.files[0])}/><button onClick={upload}>Upload & Analyze</button>{resume&&<div className="resume"><div className="score">{resume.ats_score}%<small>ATS Match</small></div><h3>Skills</h3><div>{resume.skills?.map(s=><span className="tag" key={s}>{s}</span>)}</div><h3>Suggestions</h3><ul>{resume.analysis?.map(a=><li key={a}>{a}</li>)}</ul></div>}</section>}
 {page==="jobs"&&<><h2>Discover Jobs</h2><div className="grid">{jobs.map(j=><JobCard key={j.id} x={{job:j,match_percentage:0}} swipe={swipe}/>)}</div></>}
 {page==="applications"&&<><h2>Application Tracking</h2>{apps.length===0?<p>No applications yet.</p>:apps.map(a=><div className="app"><b>{a.title}</b> — {a.company}<span>{a.status}</span></div>)}</>}
 </main></div>
}

function JobCard({x,swipe}){let j=x.job;return <div className="card"><div className="match">{x.match_percentage}% Match</div><h3>{j.title}</h3><b>{j.company}</b><p>📍 {j.location} · {j.job_type}</p><p>{j.experience} · {j.salary}</p><p>{j.description}</p><div>{j.skills?.slice(0,6).map(s=><span className="tag" key={s}>{s}</span>)}</div><div className="actions"><button onClick={()=>swipe(j.id,"left")}>✕ Skip</button><button onClick={()=>swipe(j.id,"right")}>♥ Apply</button></div></div>}
